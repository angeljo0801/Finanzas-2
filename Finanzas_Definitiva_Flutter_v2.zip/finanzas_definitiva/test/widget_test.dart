import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Flutter construye una pantalla básica', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Text('Finanzas Definitiva')));
    expect(find.text('Finanzas Definitiva'), findsOneWidget);
  });
}
